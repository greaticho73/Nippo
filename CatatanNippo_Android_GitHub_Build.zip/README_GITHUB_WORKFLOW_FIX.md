# GitHub Actions Workflow Fix

The project no longer uses an unzip step for `CatatanNippo_Android_GitHub_Build.zip`.

GitHub Actions workflow location:
`.github/workflows/build-apk.yml`

The workflow builds directly from the repository root and explicitly installs
and verifies Gradle 8.11.1.

If an older workflow still appears in GitHub Actions, delete or replace that
old workflow file in `.github/workflows/` before running the new workflow.
