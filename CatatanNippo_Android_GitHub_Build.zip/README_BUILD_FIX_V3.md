# Build Fix V3

Perbaikan untuk GitHub Actions setelah upgrade Android Gradle Plugin ke 8.9.1.

- Gradle Actions: 8.10.2 -> 8.11.1
- AGP 8.9.1 membutuhkan Gradle >= 8.11.1.
- compileSdk 36 dan AndroidX tetap dipertahankan.
