# Build APK langsung dari HP Android

Cara paling mudah tanpa PC adalah memakai GitHub Actions.

1. Buat repository baru di GitHub, misalnya `catatan-nippo-android`.
2. Upload folder `CatatanNippo_Android` beserta seluruh isinya ke repository.
3. Buat folder `.github/workflows/` di repository.
4. Upload file `build-apk.yml` ke `.github/workflows/build-apk.yml`.
5. Buka tab **Actions** → workflow **Build Catatan Nippo APK** → **Run workflow**.
6. Setelah selesai, buka hasil workflow → **Artifacts** → `Catatan-Nippo-debug-apk` → download ZIP.
7. Ekstrak ZIP di HP dan instal `app-debug.apk`.

Workflow akan memasang Android SDK 35, Gradle 8.10.2 dan JDK 17 di cloud GitHub, kemudian menghasilkan APK debug.

Tidak perlu Android Studio atau PC.
