# Gradle 8.11.1 Fix

This project explicitly forces **Gradle 8.11.1** in GitHub Actions.

The workflow:
- installs Gradle 8.11.1 with `gradle/actions/setup-gradle@v4`
- runs `gradle --version`
- verifies the reported version is exactly `8.11.1`
- builds the signed release APK with `gradle assembleRelease --no-daemon`

A workflow is also provided at `.github/workflows/build-apk.yml`, so GitHub Actions can build directly from the repository without relying on an older workflow bundled elsewhere.

This fixes the error where Android Gradle Plugin 8.9.1 detected Gradle 8.10.2.
