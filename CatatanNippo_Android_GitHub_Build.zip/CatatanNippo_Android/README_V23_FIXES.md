# Catatan Nippo V23 — Bug Fix + UI Reference Restore
Version: 1.5.1 (versionCode 17)

- Fixed Finish Activity with direct event listener and native end capture.
- Ongoing activities capture the device step-counter baseline.
- Activity count is stable and uses total saved activity records.
- Removed V22 compact UI override and restored fuller reference proportions.
- Added welcome screen at the beginning of each app session.
- Expanded activity detail UI with status, duration, health, note and finish action.
- Package remains com.catatannippo.restore.
- Default language remains Japanese.
