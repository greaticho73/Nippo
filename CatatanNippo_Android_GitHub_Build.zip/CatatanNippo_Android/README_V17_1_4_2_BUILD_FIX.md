# Catatan Nippo 1.4.2 – Build Fix

Perbaikan berdasarkan GitHub Actions run #53:
- `Energy.fromCalories(double)` diganti/dipastikan menggunakan `Energy.fromKilocalories(double)` pada Health Connect.
- `activityHealthPrefs()` dibuat public agar dapat dipanggil Bridge.
- `readDeviceStepCounter()` dibuat public agar dapat dipanggil Bridge.
- Tidak mengubah applicationId `com.catatannippo.restore`.
- Version code 11, version name 1.4.2.

Build final tetap harus diverifikasi oleh GitHub Actions.
