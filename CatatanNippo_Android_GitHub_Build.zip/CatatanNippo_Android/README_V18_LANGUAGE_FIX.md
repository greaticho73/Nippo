# Catatan Nippo V18 / 1.4.3 — Language System Fix

Perbaikan bahasa sistem dan seluruh UI aplikasi.

## Bahasa
- Default instalasi baru: **日本語 (Japanese)**.
- Pilihan: **日本語 / Indonesia / English**.
- Urutan tombol bahasa: 日本語 → Indonesia → English → 日本語.
- Bahasa yang dipilih disimpan di `nippo.lang` dan `nippo.language`.
- Bahasa juga dikirim ke Android native layer agar dialog/toast/notifikasi aplikasi mengikuti bahasa yang dipilih.

## Cakupan UI
- Dashboard dan kartu statistik.
- Navigasi bawah.
- Form catatan kegiatan.
- Riwayat dan detail kegiatan.
- Ringkasan waktu dan grafik per jam.
- Kegiatan yang sedang berjalan.
- To Do dan status/remaining time.
- Data, backup, restore, dan hapus data.
- Pengaturan alarm dan sinkronisasi kesehatan.
- Health Connect, Google Fit, dan Samsung Health labels.
- Tentang aplikasi.
- Konfirmasi, toast, error/import messages.
- Android native health dialogs/toasts dan reminder notification text.
- Satuan durasi mengikuti bahasa: Jepang `時間/分/日`, Indonesia `j/m/h`, English `h/m/d`.

## Build
- package: `com.catatannippo.restore`
- versionCode: `12`
- versionName: `1.4.3`
- minSdk: `26`
- compileSdk/targetSdk: `36/35`
- Gradle: `8.11.1`

## Catatan
Source telah divalidasi dengan `node --check` untuk seluruh blok JavaScript dan pemeriksaan keseimbangan kurung Java. Build Android final tetap dijalankan melalui GitHub Actions.
