# Catatan Nippo V16 — bugfix video + akurasi kesehatan

Versi aplikasi: 1.3.0 (versionCode 8)

Perubahan utama:
- Kartu `Jumlah catatan` membuka mode `Riwayat kegiatan` saja, tanpa form `Catat kegiatan`.
- Kegiatan yang sedang berjalan pada `Kegiatan hari ini` sekarang membuka detail kegiatan ketika diketuk sehingga tombol `Catat selesai sekarang` dapat digunakan.
- Konfirmasi pengakhiran kegiatan tetap dipakai.
- Bahasa dibuat konsisten untuk Indonesia, English, dan 日本語 termasuk navigasi bawah dan halaman About.
- Label angka/jam di bawah dan di atas batang grafik waktu dihilangkan; informasi detail tetap tersedia lewat tooltip.
- Health Connect tetap menjadi sumber utama untuk langkah dan kalori. Agregasi langkah digunakan agar duplikasi dari beberapa sumber ditangani oleh Health Connect.
- Jika Health Connect tidak tersedia/izin belum diberikan, aplikasi mencoba memakai sensor `TYPE_STEP_COUNTER` perangkat berdasarkan baseline saat kegiatan ongoing dibuat. Jika baseline sensor tidak tersedia, baru memakai perkiraan berbasis durasi.
- Perkiraan fallback ditandai sebagai `Perkiraan/Estimated/推定値` dan tidak dipresentasikan sebagai data kesehatan nyata.

Catatan: sensor langkah perangkat dan Health Connect bergantung pada dukungan perangkat, izin, dan ketersediaan data. Nilai kalori fallback tetap merupakan estimasi.
