# Build fix

GitHub Actions sebelumnya gagal pada `compileDebugJavaWithJavac` karena
`MainActivity.java` menggunakan `Toast` tetapi belum mengimpor:

`import android.widget.Toast;`

Import tersebut sudah ditambahkan pada versi ini.

Build command:
`gradle assembleDebug --no-daemon`
