# V15 Health Connect / First Run Fix

- Fixes the Java compile error caused by `JSONObject.putOpt(...)` declaring `JSONException` in this Android/Java environment.
- The exception fallback now safely catches `JSONException` while building the result object.
- Keeps the first-run suggestion dialog recommending Google Fit and Samsung Health, with Health Connect synchronization guidance.
- Version: 1.2.2 (versionCode 7).
- minSdk remains 26 for Health Connect 1.1.0.
