# 日報記録 — Android HP Final

Project ini adalah versi final untuk dikompilasi menjadi APK.

## Isi
- Interface mengikuti desain HP terakhir.
- Istilah dan alur mengikuti versi HP sebelumnya.
- Nama aplikasi Android: **日報記録**
- Bahasa: 日本語 / Indonesia
- Halaman Data terpisah dari Dashboard.
- Backup Export memakai Android `ACTION_CREATE_DOCUMENT`.
- Backup Import memakai WebView file chooser.
- Data disimpan di localStorage.
- Package: `com.catatannippo.restore` agar aplikasi lama tidak perlu dihapus.

## Build GitHub Actions
Workflow project dapat menjalankan:

```bash
./gradlew assembleDebug --no-daemon
```

APK debug:
`app/build/outputs/apk/debug/`
