# Catatan Nippo V22 — UI Upgrade

Based on the uploaded mobile UI reference.

## UI changes
- Compact dark-navy mobile header
- Running activity card on dashboard
- 2x2 dashboard statistic cards
- 3-column quick actions
- Compact backup/delete actions
- Five-item bottom navigation including その他 / Lainnya / More
- Existing activity, To Do, data, settings, Health Connect, language and finish-activity features retained from the previous source
- Default language remains Japanese (日本語), with Indonesian and English switching

## Version
- versionCode: 16
- versionName: 1.5.0
