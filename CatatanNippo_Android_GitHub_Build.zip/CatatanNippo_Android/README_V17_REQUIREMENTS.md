# Catatan Nippo V17 / 1.4.0

Perubahan utama:

- `記録数` membuka riwayat kegiatan dengan default tanggal hari ini; tanggal dapat diganti. Jumlah pada kartu juga mengikuti jumlah kegiatan hari ini.
- Mengetuk kegiatan pada riwayat membuka detail kegiatan. Kegiatan yang sedang berjalan memiliki tombol selesai.
- `本日の合計時間` membuka rangkuman per hari, dengan grafik 24 jam tanpa tulisan angka waktu di batang. Setiap batang dapat diketuk untuk melihat daftar kegiatan pada jam tersebut.
- `今日の活動` membuka halaman seluruh kegiatan hari yang dipilih, dengan kartu teratas untuk kegiatan yang sedang berlangsung dan langkah/kalori live dari sensor perangkat bila tersedia.
- `未完了タスク` menampilkan To Do mendatang dengan remaining time; `完了タスク` menampilkan semua To Do yang selesai.
- `活動を記録`, `やることリスト`, `データのバックアップ`, dan `すべてのデータを削除` diarahkan ke halaman masing-masing.
- Menambahkan halaman `設定` dengan alarm, sinkronisasi kesehatan, izin Health Connect, tombol Google Fit/Samsung Health, dan informasi aplikasi dalam Indonesia/English/日本語.
- Sinkronisasi kesehatan memakai Health Connect sebagai hub. Google Fit dan Samsung Health dapat berbagi data melalui Health Connect; Catatan Nippo membaca aggregate steps/active calories untuk menghindari double counting.
- Jika data Health Connect tidak tersedia, fallback menggunakan `TYPE_STEP_COUNTER` bila sensor HP tersedia; kalori fallback diberi label perkiraan.
- Data fallback hanya ditulis kembali ke Health Connect ketika sinkronisasi diaktifkan. Data yang sudah berasal dari Health Connect tidak ditulis ulang agar tidak menggandakan data.
- First launch: saran pemasangan Google Fit/Samsung Health. Pada pembukaan berikutnya, bila salah satu aplikasi terdeteksi dan sinkronisasi belum diatur, tampil dialog pengaturan sinkronisasi.
- Bahasa: Indonesia / English / 日本語.

## Build

- package: `com.catatannippo.restore`
- versionCode: `9`
- versionName: `1.4.0`
- minSdk: `26`
- compileSdk/targetSdk: `36/35`
- Gradle: `8.11.1`

## Catatan akurasi kesehatan

Health Connect adalah sumber utama ketika izin tersedia. Dokumentasi Android menyarankan aggregate untuk data kumulatif seperti langkah agar data dari beberapa sumber tidak dihitung dua kali. Pada Android 14+ dengan dukungan yang sesuai, Health Connect juga dapat memasukkan langkah dari sensor HP ke agregat. Fallback sensor langsung dipakai bila Health Connect tidak tersedia/berizin. Kalori dari sensor langkah saja tetap merupakan estimasi, karena sensor langkah tidak mengukur energi secara langsung.
