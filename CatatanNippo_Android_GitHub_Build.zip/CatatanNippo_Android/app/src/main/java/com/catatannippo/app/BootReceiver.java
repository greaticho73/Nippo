package com.catatannippo.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent in){new Bridge(c.getApplicationContext()).rescheduleAll();}
}
