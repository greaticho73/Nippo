package com.catatannippo.app;
import android.app.*;import android.content.*;import android.os.Build;import android.text.TextUtils;import org.json.JSONObject;
public class ReminderReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent in){
  String ch="nippo_reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26){NotificationChannel nc=new NotificationChannel(ch,"日報記録",NotificationManager.IMPORTANCE_HIGH);nc.setDescription("やることのリマインダー");nc.enableVibration(true);nm.createNotificationChannel(nc);}
  String id=in.getStringExtra("id"),title=in.getStringExtra("title"),detail=in.getStringExtra("detail");int slot=in.getIntExtra("slot",0);if(TextUtils.isEmpty(id))return;
  String stored=c.getSharedPreferences(Bridge.PREFS,Context.MODE_PRIVATE).getString(id,null);if(stored==null)return;
  try{JSONObject o=new JSONObject(stored);if(o.optBoolean("done",false))return;title=o.optString("title",title==null?"To Do":title);detail=o.optString("detail",detail==null?"":detail);}catch(Exception ignored){}
  String when=slot==0?"10分前":slot==1?"8分前":slot==2?"6分前":slot==3?"4分前":slot==4?"2分前":"開始時刻";
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title==null?"To Do":title).setContentText((detail==null||detail.isEmpty()?"やることの時間です":detail)+" • "+when).setAutoCancel(true).setContentIntent(open).setPriority(Notification.PRIORITY_HIGH);nm.notify((id+":"+slot).hashCode(),b.build());
 }
}
