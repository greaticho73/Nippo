package com.catatannippo.app;
import android.app.*;import android.content.*;import android.os.Build;import android.text.TextUtils;import org.json.JSONObject;
public class ReminderReceiver extends BroadcastReceiver{
 private static final long REPEAT_MS=3*60*1000L;
 @Override public void onReceive(Context c,Intent in){
  String ch="nippo_reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26){NotificationChannel nc=new NotificationChannel(ch,"日報記録",NotificationManager.IMPORTANCE_HIGH);nc.setDescription("To Do のリマインダー");nc.enableVibration(true);nm.createNotificationChannel(nc);}
  String id=in.getStringExtra("id"),title=in.getStringExtra("title"),detail=in.getStringExtra("detail");if(TextUtils.isEmpty(id))id=title==null?"todo":title;
  String stored=c.getSharedPreferences(Bridge.PREFS,Context.MODE_PRIVATE).getString(id,null);if(stored==null)return;
  try{JSONObject o=new JSONObject(stored);if(o.optBoolean("done",false))return;title=o.optString("title",title==null?"To Do":title);detail=o.optString("detail",detail==null?"":detail);}catch(Exception ignored){}
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title==null?"To Do":title).setContentText((detail==null||detail.isEmpty()?"To Do の時間です":detail)+" • 3分ごとに通知します").setAutoCancel(true).setContentIntent(open).setPriority(Notification.PRIORITY_HIGH);nm.notify(id.hashCode(),b.build());
  Intent next=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id).putExtra("title",title).putExtra("detail",detail);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),next,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);long at=System.currentTimeMillis()+REPEAT_MS;if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
 }
}
