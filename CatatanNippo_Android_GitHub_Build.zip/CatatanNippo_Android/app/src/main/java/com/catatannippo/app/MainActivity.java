package com.catatannippo.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        if(Build.VERSION.SDK_INT>=31){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(!am.canScheduleExactAlarms()) try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception ignored){} }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}

class Bridge {
    private final Context c; private final android.content.SharedPreferences prefs;
    Bridge(Context c){this.c=c; prefs=c.getSharedPreferences("alarms",Context.MODE_PRIVATE);}
    @android.webkit.JavascriptInterface public void scheduleTodo(String json){
        try{ JSONObject o=new JSONObject(json); String id=o.getString("id"), title=o.getString("title"), detail=o.optString("detail"), date=o.getString("date"), time=o.getString("time");
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US); f.setTimeZone(TimeZone.getDefault()); Date d=f.parse(date+" "+time); if(d==null||d.getTime()<=System.currentTimeMillis())return; schedule(id,title,detail,d.getTime()); prefs.edit().putString(id,json).apply();
        }catch(Exception ignored){}
    }
    @android.webkit.JavascriptInterface public void cancelTodo(String id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); Intent i=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id); am.cancel(PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)); prefs.edit().remove(id).apply();
    }
    private void schedule(String id,String title,String detail,long at){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); Intent i=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id).putExtra("title",title).putExtra("detail",detail); PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);
    }
    void rescheduleAll(){ for(String v:prefs.getAll().values().toString().split("\\n")){} for(Map.Entry<String,?> e:prefs.getAll().entrySet()){ try{scheduleTodo((String)e.getValue());}catch(Exception ignored){} } }
}
