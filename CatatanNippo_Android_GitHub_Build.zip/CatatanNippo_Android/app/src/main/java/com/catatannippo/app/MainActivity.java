package com.catatannippo.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.Toast;
import android.webkit.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.ResultKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import org.json.*;
import androidx.health.connect.client.HealthConnectClient;
import androidx.health.connect.client.records.StepsRecord;
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord;
import androidx.health.connect.client.request.AggregateRequest;
import androidx.health.connect.client.time.TimeRangeFilter;

public class MainActivity extends Activity {
    WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7001;
    private static final int CREATE_BACKUP_REQUEST = 7002;
    private String pendingBackupJson;
    private ExecutorService healthExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch(Exception e){ filePathCallback=null; return false; }
            }
        });
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        android.content.SharedPreferences prefs=getSharedPreferences("catatan_nippo_prefs",MODE_PRIVATE);
        boolean firstRun=!prefs.getBoolean("health_apps_suggestion_shown",false);
        if(firstRun){
            prefs.edit().putBoolean("health_apps_suggestion_shown",true).apply();
            showHealthAppsSuggestion();
        } else {
            requestExactAlarmIfNeeded();
        }
    }

    private void showHealthAppsSuggestion(){
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle("Saran untuk data kesehatan")
            .setMessage("Agar data langkah dan kalori yang dibaca Catatan Nippo lebih lengkap, disarankan memasang Google Fit dan Samsung Health. Setelah terpasang, aktifkan sinkronisasi ke Health Connect dan berikan izin yang diperlukan. Aplikasi tetap dapat digunakan tanpa keduanya.")
            .setNeutralButton("Google Fit", (d,w) -> openStoreOrWeb("com.google.android.apps.fitness"))
            .setNegativeButton("Samsung Health", (d,w) -> openStoreOrWeb("com.sec.android.app.shealth"))
            .setPositiveButton("Lewati", null)
            .create();
        dialog.setOnDismissListener(d -> requestExactAlarmIfNeeded());
        dialog.show();
    }

    private void requestExactAlarmIfNeeded(){
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!am.canScheduleExactAlarms()) try{
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));
            }catch(Exception ignored){}
        }
    }

    private void openStoreOrWeb(String packageName){
        try{
            Intent market=new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+packageName));
            startActivity(market);
        }catch(Exception e){
            try{
                Intent webIntent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+packageName));
                startActivity(webIntent);
            }catch(Exception ignored){}
        }
    }

    void exportBackupFile(String json){
        pendingBackupJson=json==null?"{}":json;
        try{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE,"CatatanNippo_Backup_"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+".json");
            startActivityForResult(intent, CREATE_BACKUP_REQUEST);
        }catch(Exception e){ Toast.makeText(this,"Tidak dapat membuka penyimpanan file",Toast.LENGTH_SHORT).show(); }
    }

    void queryHealth(final String callbackId, final String start, final String end){
        healthExecutor.execute(() -> {
            JSONObject result = new JSONObject();
            try {
                result.put("id", callbackId);
                Instant s=LocalDateTime.parse(start.replace(' ','T')).atZone(ZoneId.systemDefault()).toInstant();
                Instant e=LocalDateTime.parse(end.replace(' ','T')).atZone(ZoneId.systemDefault()).toInstant();
                HealthConnectClient client=HealthConnectClient.getOrCreate(this,"com.google.android.apps.healthdata");
                Set<String> perms=new HashSet<>();
                perms.add("android.permission.health.READ_STEPS");
                perms.add("android.permission.health.READ_ACTIVE_CALORIES_BURNED");

                Set<String> granted=awaitSuspend(continuation ->
                    client.getPermissionController().getGrantedPermissions(continuation));

                if(granted.containsAll(perms)){
                    Set<androidx.health.connect.client.aggregate.AggregateMetric<?>> metrics=new HashSet<>();
                    metrics.add(StepsRecord.COUNT_TOTAL);
                    metrics.add(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL);
                    AggregateRequest request=new AggregateRequest(
                        metrics,
                        TimeRangeFilter.between(s,e),
                        java.util.Collections.emptySet());
                    androidx.health.connect.client.aggregate.AggregationResult r=awaitSuspend(
                        continuation -> client.aggregate(request, continuation));

                    Long steps=(Long)r.get(StepsRecord.COUNT_TOTAL);
                    Object energy=r.get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL);
                    double kcal=0;
                    if(energy!=null) try{kcal=((Number)energy.getClass().getMethod("getInKilocalories").invoke(energy)).doubleValue();}catch(Exception ignored){}
                    result.put("source","health_connect");
                    result.put("steps",steps==null?0:steps);
                    result.put("calories",kcal);
                    result.put("authorized",true);
                } else {
                    result.put("source","estimate");
                    result.put("authorized",false);
                    result.put("permissionNeeded",true);
                }
            }catch(Exception ex){
                result.putOpt("source","estimate");
                result.putOpt("authorized",false);
                result.putOpt("error",ex.getClass().getSimpleName());
            }
            final String js="window.onHealthResult && window.onHealthResult("+JSONObject.quote(result.toString())+");";
            runOnUiThread(() -> { if(web!=null) web.evaluateJavascript(js,null); });
        });
    }

    private interface SuspendCall<T> {
        Object invoke(Continuation<? super T> continuation);
    }

    private static <T> T awaitSuspend(SuspendCall<T> call) throws Exception {
        CountDownLatch latch=new CountDownLatch(1);
        AtomicReference<Object> value=new AtomicReference<>();
        AtomicReference<Throwable> error=new AtomicReference<>();
        Continuation<T> continuation=new Continuation<T>(){
            @Override public kotlin.coroutines.CoroutineContext getContext(){
                return EmptyCoroutineContext.INSTANCE;
            }
            @Override public void resumeWith(Object result){
                try{
                    ResultKt.throwOnFailure(result);
                    value.set(result);
                }catch(Throwable t){
                    error.set(t);
                }finally{
                    latch.countDown();
                }
            }
        };
        Object immediate;
        try{
            immediate=call.invoke(continuation);
        }catch(Throwable t){
            throw new Exception(t);
        }
        if(immediate!=IntrinsicsKt.getCOROUTINE_SUSPENDED()){
            try{ ResultKt.throwOnFailure(immediate); }catch(Throwable t){ throw new Exception(t); }
            @SuppressWarnings("unchecked") T cast=(T)immediate;
            return cast;
        }
        if(!latch.await(30,TimeUnit.SECONDS)) throw new TimeoutException("Health Connect request timed out");
        Throwable t=error.get();
        if(t!=null) throw new Exception(t);
        @SuppressWarnings("unchecked") T cast=(T)value.get();
        return cast;
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_REQUEST){
            if(filePathCallback!=null){ Uri[] results=null; if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null) results=new Uri[]{data.getData()}; filePathCallback.onReceiveValue(results); filePathCallback=null; }
        } else if(requestCode==CREATE_BACKUP_REQUEST){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackupJson!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){ if(os!=null){os.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));os.flush();Toast.makeText(this,"Backup berhasil disimpan",Toast.LENGTH_SHORT).show();} }
                catch(Exception e){Toast.makeText(this,"Gagal menyimpan backup",Toast.LENGTH_SHORT).show();}
            }
            pendingBackupJson=null;
        }
    }
    @Override protected void onResume(){super.onResume();if(web!=null)web.evaluateJavascript("window.refreshHealth&&window.refreshHealth();",null);}
    @Override protected void onDestroy(){healthExecutor.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){
        if(web==null){super.onBackPressed();return;}
        web.evaluateJavascript("(window.handleNativeBack ? window.handleNativeBack() : false);", value -> {
            if("false".equals(value) || "null".equals(value)){
                MainActivity.super.onBackPressed();
            }
        });
    }
}

class Bridge {
    static final String PREFS="alarms"; static final String DATA_BACKUP_PREFS="nippo_data_backup";
    private final Context c; private final android.content.SharedPreferences prefs;
    Bridge(Context c){this.c=c; prefs=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    @android.webkit.JavascriptInterface public void exportBackup(String json){if(c instanceof MainActivity)((MainActivity)c).exportBackupFile(json);}
    @android.webkit.JavascriptInterface public void healthForActivity(String id,String start,String end){if(c instanceof MainActivity)((MainActivity)c).queryHealth(id,start,end);}
    @android.webkit.JavascriptInterface public void openHealthSettings(){try{Intent i=HealthConnectClient.getHealthConnectManageDataIntent(c,"com.google.android.apps.healthdata");i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception e){try{c.startActivity(new Intent(HealthConnectClient.getHealthConnectSettingsAction()));}catch(Exception ignored){}}}
    @android.webkit.JavascriptInterface public void scheduleTodo(String json){
        try{ JSONObject o=new JSONObject(json); String id=o.getString("id"),date=o.getString("date"),time=o.getString("time"); prefs.edit().putString(id,json).apply(); cancelAlarms(id);
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US); f.setTimeZone(TimeZone.getDefault()); Date d=f.parse(date+" "+time); if(d==null)return;
            long start=d.getTime()-10*60*1000L;
            for(int i=0;i<6;i++){ long at=start+i*2*60*1000L; if(at>System.currentTimeMillis())schedule(id,o.optString("title","To Do"),o.optString("detail",""),at,i); }
        }catch(Exception ignored){}
    }
    @android.webkit.JavascriptInterface public void cancelTodo(String id){cancelAlarms(id);prefs.edit().remove(id).apply();}
    private int requestCode(String id,int slot){return (id+":"+slot).hashCode();}
    private void cancelAlarms(String id){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);for(int i=0;i<6;i++){Intent in=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id).putExtra("slot",i);PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(id,i),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}}
    private void schedule(String id,String title,String detail,long at,int slot){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent in=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id).putExtra("slot",slot).putExtra("title",title).putExtra("detail",detail);PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(id,slot),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);}
    void rescheduleAll(){for(Map.Entry<String,?> e:prefs.getAll().entrySet())if(e.getValue() instanceof String)try{JSONObject o=new JSONObject((String)e.getValue());String id=e.getKey(),date=o.getString("date"),time=o.getString("time");SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);Date d=f.parse(date+" "+time);if(d==null)continue;cancelAlarms(id);long base=d.getTime()-10*60*1000L;for(int i=0;i<6;i++){long at=base+i*2*60*1000L;if(at>System.currentTimeMillis())schedule(id,o.optString("title","To Do"),o.optString("detail",""),at,i);}}catch(Exception ignored){}}
}
