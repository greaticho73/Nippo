package com.catatannippo.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.res.AssetManager;
import android.provider.MediaStore;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.Toast;
import android.webkit.*;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7001;
    private static final int CREATE_BACKUP_REQUEST = 7002;
    private String pendingBackupJson;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try{
                    Intent intent=params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                }catch(Exception e){
                    filePathCallback=null;
                    return false;
                }
            }
        });
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");

        if(Build.VERSION.SDK_INT>=33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        if(Build.VERSION.SDK_INT>=31){
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!am.canScheduleExactAlarms()) try{
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:"+getPackageName())));
            }catch(Exception ignored){}
        }
    }

    void exportBackupFile(String json){
        pendingBackupJson=json==null?"{}":json;
        try{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE,
                "CatatanNippo_Backup_"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+".json");
            startActivityForResult(intent, CREATE_BACKUP_REQUEST);
        }catch(Exception e){
            Toast.makeText(this,"Tidak dapat membuka penyimpanan file",Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_REQUEST){
            if(filePathCallback!=null){
                Uri[] results=null;
                if(resultCode==RESULT_OK && data!=null){
                    Uri u=data.getData();
                    if(u!=null) results=new Uri[]{u};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback=null;
            }
        }else if(requestCode==CREATE_BACKUP_REQUEST){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackupJson!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){
                    if(os!=null){
                        os.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                        Toast.makeText(this,"Backup berhasil disimpan",Toast.LENGTH_SHORT).show();
                    }
                }catch(Exception e){
                    Toast.makeText(this,"Gagal menyimpan backup",Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson=null;
        }
    }

    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}

class Bridge {
    static final String PREFS="alarms";
    static final String DATA_BACKUP_PREFS="nippo_data_backup";
    private final Context c; private final android.content.SharedPreferences prefs;
    Bridge(Context c){this.c=c; prefs=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    @android.webkit.JavascriptInterface public void exportBackup(String json){
        if(c instanceof MainActivity) ((MainActivity)c).exportBackupFile(json);
    }
    @android.webkit.JavascriptInterface public void scheduleTodo(String json){
        try{ JSONObject o=new JSONObject(json); String id=o.getString("id"),title=o.getString("title"),detail=o.optString("detail"),date=o.getString("date"),time=o.getString("time");
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US); f.setTimeZone(TimeZone.getDefault()); Date d=f.parse(date+" "+time); if(d==null)return;
            prefs.edit().putString(id,json).apply(); long at=d.getTime(); if(at<=System.currentTimeMillis())at=System.currentTimeMillis()+1000L; schedule(id,title,detail,at);
        }catch(Exception ignored){}
    }
    @android.webkit.JavascriptInterface public void cancelTodo(String id){cancelAlarm(id);prefs.edit().remove(id).apply();}
    @android.webkit.JavascriptInterface public void backupData(String activities,String todos,String lang){
        try{
            c.getSharedPreferences(DATA_BACKUP_PREFS,Context.MODE_PRIVATE).edit()
                .putString("activities",activities==null?"[]":activities)
                .putString("todos",todos==null?"[]":todos)
                .putString("lang",lang==null?"ja":lang)
                .putLong("saved_at",System.currentTimeMillis())
                .apply();
        }catch(Exception ignored){}
    }
    @android.webkit.JavascriptInterface public String restoreData(){
        try{
            android.content.SharedPreferences p=c.getSharedPreferences(DATA_BACKUP_PREFS,Context.MODE_PRIVATE);
            JSONObject o=new JSONObject();
            o.put("activities",p.getString("activities","[]"));
            o.put("todos",p.getString("todos","[]"));
            o.put("lang",p.getString("lang","ja"));
            o.put("saved_at",p.getLong("saved_at",0L));
            return o.toString();
        }catch(Exception e){return "{}";}
    }
    private void cancelAlarm(String id){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent i=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id);PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
    void scheduleFromStored(String id,String json,long delayMs){try{JSONObject o=new JSONObject(json);schedule(id,o.optString("title","To Do"),o.optString("detail",""),System.currentTimeMillis()+delayMs);}catch(Exception ignored){}}
    private void schedule(String id,String title,String detail,long at){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent i=new Intent(c,ReminderReceiver.class).setAction("NIPPO_REMINDER").putExtra("id",id).putExtra("title",title).putExtra("detail",detail);PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);}
    void rescheduleAll(){for(Map.Entry<String,?> e:prefs.getAll().entrySet())if(e.getValue() instanceof String)scheduleFromStored(e.getKey(),(String)e.getValue(),1000L);}
}
