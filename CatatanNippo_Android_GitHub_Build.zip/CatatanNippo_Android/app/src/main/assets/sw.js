
/* NIPPO_CONFIRM_V9
 * Confirmation before an activity or To Do is ended.
 */
window.nippoConfirmFinish = function(name, kind) {
  const label = kind || "kegiatan";
  const title = name || "ini";
  return window.confirm("Apakah yakin akan mengakhiri " + label + " '" + title + "'?");
};

const CACHE='catatan-nippo-v1';const FILES=['./','./index.html','./style.css','./app.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())));self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(x=>{let y=x.clone();caches.open(CACHE).then(c=>c.put(e.request,y));return x}).catch(()=>caches.match('./index.html')))));self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(w=>w[0]?w[0].focus():clients.openWindow('./index.html')))})