# Build Fix V2

Fixed Health Connect 1.1.0 build requirements:
- Android Gradle Plugin 8.9.1
- compileSdk 36
- GitHub Actions installs Android SDK 36 / build-tools 36.0.0
- AndroidX remains enabled.

This is required because Health Connect 1.1.0 requires compileSdk 36+ and AGP 8.9.1+.
