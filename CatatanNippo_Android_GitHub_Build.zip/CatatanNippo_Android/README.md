Catatan Nippo Android v1.0.2

This build uses a fixed signing keystore so future builds can use the same signing identity.
Keep the signing/ directory private and do not publish the keystore.

Important: this signing key is new. An APK signed with it cannot replace an older APK that was signed with a different key. The currently installed older Catatan Nippo APK must remain installed until its data has been safely migrated.


## v1.1.0 Recovery
Separate package `com.catatannippo.restore` to install alongside the legacy app. Includes recovered data and JSON import/export.
