# UI final — statistik clickable & icon consistency

Perubahan:
- 4 kartu statistik sekarang dapat ditekan.
  - 記録数 -> 活動記録
  - 本日の合計時間 -> 活動記録
  - 未完了タスク -> やること
  - 完了タスク -> やること
- Icon kartu/tombol diganti SVG inline agar bentuk dan ukuran konsisten.
- Ukuran icon dibuat responsif untuk layar <=800 dan <=520.
- Arrow, data icon, action icon, dan bottom-navigation icon memakai sistem ukuran yang konsisten.
- Nama aplikasi tetap 日報記録.
