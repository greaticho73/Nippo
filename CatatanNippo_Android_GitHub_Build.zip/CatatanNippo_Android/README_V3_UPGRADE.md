# 日報記録 1.2.0 — V3 Upgrade

Tambahan fungsi:

- 記録数: daftar seluruh kegiatan dengan default hari ini, pilihan tanggal lain, dan detail kegiatan saat diketuk.
- Detail kegiatan menampilkan durasi, langkah, dan kalori. Jika Health Connect memiliki data dari sumber kesehatan yang terhubung, data aktual dibaca. Jika tidak tersedia/izin belum diberikan, aplikasi menampilkan estimasi berdasarkan durasi aktivitas.
- 本日の合計時間: halaman ringkasan tanggal dengan total waktu dan grafik 24 jam berbentuk bar seperti konsep Popular Times.
- 未完了タスク: daftar To Do yang belum selesai dengan remaining time menuju To Do terdekat.
- 完了タスク: daftar To Do yang sudah selesai.
- Alarm/notifikasi To Do: 10, 8, 6, 4, 2 menit sebelum waktu mulai dan tepat pada waktu mulai. Jadwal menggunakan alarm Android dan tidak lagi mengulang tanpa batas setelah kegiatan dimulai.
- Backup/restore tetap menggunakan mekanisme Android yang sudah diperbaiki.
- Nama aplikasi: 日報記録.
- Package tetap: com.catatannippo.restore.

Catatan Health Connect:
Aplikasi membaca data melalui Health Connect. Data dari Samsung Health atau Google Fit hanya dapat digunakan bila sumber tersebut menyediakan/menyinkronkan data ke Health Connect dan pengguna memberikan izin baca yang diperlukan. Jika tidak, aplikasi memakai estimasi.

Build:
`gradle assembleDebug --no-daemon`

Catatan: lingkungan pembuatan ini tidak memiliki executable Gradle, sehingga build APK tidak dijalankan di sini; source project sudah disiapkan untuk workflow GitHub Actions.
