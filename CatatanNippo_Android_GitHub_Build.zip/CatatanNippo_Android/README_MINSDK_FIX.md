Build fix: androidx.health.connect:connect-client:1.1.0 requires minSdk 26, so app minSdk was raised from 23 to 26. No other application feature was intentionally changed.
