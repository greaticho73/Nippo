# Catatan Nippo — HP Final

Project Android siap dikompilasi menjadi APK.

- UI: `app/src/main/assets/index.html`
- Fungsi dan istilah: mengikuti versi HP sebelumnya.
- Package: `com.catatannippo.restore` agar dapat dipasang berdampingan dengan aplikasi lama.
- Signing: menggunakan konfigurasi project recovery sebelumnya.
- Build: GitHub Actions `gradle assembleDebug --no-daemon` atau Android Studio/Gradle.
