# Catatan Nippo — HP Final FIXED

Project Android siap dikompilasi.

Perbaikan:
- Export backup memakai native Android `ACTION_CREATE_DOCUMENT`, sehingga bekerja di WebView.
- Import backup memakai `WebChromeClient.onShowFileChooser`, sehingga pemilihan file JSON bekerja di WebView.
- Halaman data dipisahkan dari dashboard; backup dan hapus data tidak lagi memenuhi dashboard.
- Tampilan/istilah tetap menggunakan versi HP dan bilingual ID/Jepang.

Package:
`com.catatannippo.restore`

Build:
`./gradlew assembleDebug --no-daemon`

APK debug akan berada di:
`app/build/outputs/apk/debug/`
