# Catatan Nippo V19 — Video Bug Fix (1.4.4)

Perbaikan berdasarkan video penggunaan 2026-09-17:

1. Dashboard sekarang mempertahankan arti kartu `記録数` sebagai total seluruh catatan, sehingga angka tidak lagi berubah dari total seluruh data menjadi jumlah catatan hari ini setelah berpindah halaman.
2. Panel `今日の活動` dipaksa dirender ulang saat dibuka dan sesudah navigasi untuk mencegah panel kosong walaupun kegiatan hari ini tersedia.
3. Filter tanggal kegiatan hari ini dibuat lebih tahan terhadap format tanggal `YYYY-MM-DD` maupun `DD/MM/YYYY`.
4. Render awal aplikasi dijalankan setelah seluruh layer UI V17 selesai dipasang, sehingga dashboard awal memakai handler dan angka yang sama dengan dashboard setelah navigasi.
5. `renderToday()` diekspos agar dapat dipanggil ulang setelah perubahan bahasa/navigasi.

VersionCode: 13
VersionName: 1.4.4
Package: com.catatannippo.restore
