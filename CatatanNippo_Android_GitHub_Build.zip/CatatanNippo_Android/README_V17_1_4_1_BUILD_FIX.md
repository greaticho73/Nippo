# Catatan Nippo 1.4.1 build fix

Fixes for GitHub Actions build #53:
- Health Connect Energy uses `Energy.fromKilocalories(double)` for `ActiveCaloriesBurnedRecord`.
- Device step counter helpers are package-visible so the JavaScript bridge can call them.
- versionCode 10 / versionName 1.4.1.

No UI/data behavior was intentionally changed in this patch.
