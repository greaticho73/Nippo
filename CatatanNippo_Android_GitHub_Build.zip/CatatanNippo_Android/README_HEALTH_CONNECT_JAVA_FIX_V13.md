# Catatan Nippo V13 - Health Connect Java API Fix

Memperbaiki integrasi AndroidX Health Connect 1.1.0 pada Java.

Perubahan utama:
- `PermissionController.getGrantedPermissions()` dipanggil melalui `Continuation` karena API Health Connect 1.1.0 adalah suspend API pada bytecode Java.
- `HealthConnectClient.aggregate()` dipanggil melalui `Continuation`.
- Timeout 30 detik ditambahkan pada panggilan Health Connect.
- Tombol pengaturan Health Connect menggunakan `HealthConnectClient.getHealthConnectManageDataIntent(...)` dan `getHealthConnectSettingsAction()`.
- `minSdk` tetap 26.

Referensi API resmi:
https://developer.android.com/reference/androidx/health/connect/client/HealthConnectClient
