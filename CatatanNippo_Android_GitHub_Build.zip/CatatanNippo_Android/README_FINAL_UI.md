Final UI matches the attached reference design. App name: 日報記録. Recovered 13 activities + 1 To Do are initialized when storage is empty. Native Android backup export/import is retained.
